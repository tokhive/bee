# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-experience.spec.ts >> S2 tabs, dialogs and narrow layout remain usable at 1440 en dark
- Location: tests/native-experience.spec.ts:282:149

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "运行详情",
+ ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]: Bee
    - navigation "Main navigation" [ref=e7]:
      - button "Overview" [ref=e8] [cursor=pointer]
      - button "AI accounts" [ref=e12] [cursor=pointer]
      - button "Diagnostics" [ref=e18] [cursor=pointer]
      - button "Settings" [ref=e21] [cursor=pointer]
    - generic [ref=e25]:
      - generic [ref=e26]:
        - text: hive.example
        - paragraph [ref=e28]: No AI account connected
      - generic [ref=e33]:
        - text: Fixture
        - generic [ref=e34]: Device and platform controls
  - generic [ref=e35]:
    - banner [ref=e36]:
      - generic [ref=e37]: This device
    - main [ref=e41]:
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "Diagnostics" [level=1] [ref=e44]
          - paragraph [ref=e45]: Check Bee runtime and connection status.
        - button "Open Hive console" [ref=e46] [cursor=pointer]
      - generic [ref=e47]:
        - generic [ref=e48]:
          - tablist "Diagnostic content" [ref=e49]:
            - tab "Check results" [ref=e50] [cursor=pointer]
            - tab "Safe logs" [selected] [ref=e51] [cursor=pointer]
          - button "Refresh logs" [active] [ref=e53] [cursor=pointer]
        - tabpanel "Safe logs" [ref=e54]:
          - region "Safe logs" [ref=e55]:
            - generic [ref=e56]:
              - heading "Safe logs" [level=2] [ref=e57]
              - paragraph [ref=e58]: Read locally retained safe events on demand.
            - generic [ref=e59]:
              - generic [ref=e60]:
                - text: Module
                - combobox "Module" [ref=e61]:
                  - option "All modules" [selected]
                  - option "Diagnostics"
                  - option "Contribution process"
                  - option "Network"
                  - option "account"
                  - option "Device"
                  - option "Connection management"
                  - option "Application"
                  - option "Export"
              - generic [ref=e62]:
                - text: Platform
                - combobox "Platform" [ref=e63]:
                  - option "All platforms" [selected]
                  - option "OpenAI"
                  - option "Claude"
              - generic [ref=e64]:
                - text: Log level
                - combobox "Log level" [ref=e65]:
                  - option "All logs" [selected]
                  - option "Information"
                  - option "Warning"
                  - option "Error"
            - list [ref=e66]:
              - listitem [ref=e67]:
                - time [ref=e68]: Nov 3, 2026, 12:03:32 AM
                - generic [ref=e69]: Information
                - generic [ref=e70]:
                  - strong [ref=e71]: hive_identity_verified
                  - group [ref=e72]:
                    - generic "Check details" [ref=e73] [cursor=pointer]
            - button "Load more logs" [ref=e75] [cursor=pointer]
      - group [ref=e76]:
        - generic "运行详情" [ref=e77]
    - contentinfo [ref=e78]:
      - text: Bee
      - generic [ref=e79]: Device binding does not automatically start contribution
```

# Test source

```ts
  198 |    const report=reply.result.report,check=(id:string,platform:string|null,status:string,code:string,next_action='accounts')=>({id,platform,status,code,next_action,observed_at:report.started_at,evidence:{http_status:'409'}});
  199 |    report.state='completed';report.finished_at=report.started_at;report.checks=[
  200 |     check('proxy',null,'fail','connection_failed','settings'),check('authorization','openai','fail','authorization_expired'),
  201 |     check('quota','openai','warning','quota_exhausted'),check('account','claude','fail','account_changed'),
  202 |     check('source','claude','skipped','source_not_selected'),check('hive',null,'pass','hive_identity_verified','diagnostics')
  203 |    ];return reply;
  204 |   };
  205 |  });
  206 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  207 |  const issues=page.locator('.nd-issues');await expect(issues.locator('li')).toHaveCount(4);
  208 |  await expect(issues.getByText('官方授权已失效',{exact:true})).toBeVisible();await expect(issues.getByText('订阅额度已耗尽',{exact:true})).toBeVisible();await expect(issues.getByText('账号在检查期间发生变化',{exact:true})).toBeVisible();
  209 |  await issues.locator('li').first().locator('summary').click();await expect(issues.locator('li').first()).toContainText('connection_failed');await expect(issues.locator('dd').first()).toHaveText('409');
  210 |  await page.getByTestId('unfinished-checks').locator(':scope > summary').click();await page.getByTestId('passed-checks').locator(':scope > summary').click();
  211 |  await expect(page.locator('.nd-checks>li')).toHaveCount(6);await expect(page.getByText('尚未选择此平台的账号',{exact:true})).toBeVisible();await expect(page.getByText('Hive 身份已核对',{exact:true})).toBeVisible();await expect(page.getByText('全部检查通过',{exact:true})).toHaveCount(0);
  212 |  await issues.getByRole('button',{name:'查看设置',exact:true}).click();await expect(tab(page,'网络与代理')).toHaveAttribute('aria-selected','true');
  213 | });
  214 | 
  215 | for(const scenario of ['empty','skipped','cancelled','passed','unknown'] as const)test(`diagnostic summary distinguishes ${scenario} reports`,async({page})=>{
  216 |  await setup(page);await page.evaluate(scenario=>{
  217 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;
  218 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  219 |    const reply=await invoke(command,args);if(command!=='diagnostics_start')return reply;
  220 |    const report=reply.result.report;report.state=scenario==='cancelled'?'cancelled':'completed';report.finished_at=report.started_at;
  221 |    report.checks=scenario==='empty'?[]:scenario==='skipped'?[report.checks[1]]:[report.checks[0]];
  222 |    if(scenario==='unknown')report.checks=[{...report.checks[0],status:'skipped',code:'not_checked'}];return reply;
  223 |   };
  224 |  },scenario);
  225 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  226 |  await expect(page.getByText(scenario==='cancelled'?'诊断已取消':'检查已完成',{exact:true})).toBeVisible();
  227 |  await expect(page.getByText('全部检查通过',{exact:true})).toHaveCount(scenario==='passed'?1:0);
  228 |  await expect(page.locator('.nd-checks>li')).toHaveCount(scenario==='empty'?0:1);
  229 | });
  230 | 
  231 | test('log filters distinguish unread and empty and reject a late result from an older filter',async({page})=>{
  232 |  await setup(page);await page.evaluate(()=>{
  233 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let reads=0;
  234 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  235 |    const reply=await invoke(command,args);if(command!=='diagnostic_logs')return reply;
  236 |    if(++reads===1)return new Promise(resolve=>{w.releaseLogs=()=>resolve(reply);});
  237 |    return {entries:[],next_cursor:null,truncated:false};
  238 |   };
  239 |  });
  240 |  await nav(page,'诊断').click();await tab(page,'安全日志').click();
  241 |  await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();
  242 |  await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect.poll(async()=>(await calls(page,'diagnostic_logs')).length).toBe(1);
  243 |  await page.getByLabel(/^模块/).selectOption('network');await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();
  244 |  await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect(page.getByText('所选范围没有保留的安全事件。',{exact:true})).toBeVisible();
  245 |  await page.evaluate(()=>{(window as any).releaseLogs();});await expect(page.getByText('所选范围没有保留的安全事件。',{exact:true})).toBeVisible();
  246 |  await expect(page.locator('.nd-log-list li')).toHaveCount(0);
  247 |  await page.getByLabel(/^平台/).selectOption('claude');await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();expect((await calls(page,'diagnostic_logs')).length).toBe(2);
  248 | });
  249 | 
  250 | test('older initial network observation cannot replace an explicit refresh or an edited proxy',async({page})=>{
  251 |  await setup(page);await page.evaluate(()=>{
  252 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let reads=0;
  253 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  254 |    const reply=await invoke(command,args);if(command!=='network_snapshot'||++reads!==1)return reply;
  255 |    return new Promise(resolve=>{w.releaseNetwork=()=>resolve({...reply,saved_proxy:'http://127.0.0.1:7801',effective_proxy:'http://127.0.0.1:7801'});});
  256 |   };
  257 |  });
  258 |  await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:7900');
  259 |  await page.getByRole('button',{name:'刷新生效路径',exact:true}).click();await expect(page.locator('.ns-network-summary')).toContainText('代理未启用');
  260 |  await page.evaluate(()=>{(window as any).releaseNetwork();});await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toHaveValue('http://127.0.0.1:7900');await expect(page.locator('.ns-network-summary')).not.toContainText('7801');
  261 | });
  262 | 
  263 | test('denied notifications and unknown autostart remain distinct without requesting OS changes',async({page})=>{
  264 |  await setup(page);await page.evaluate(()=>{
  265 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;
  266 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  267 |    const value=await invoke(command,args);if(command==='notification_permission')return 'denied';
  268 |    if(command==='autostart_status')return {desired:false,registered:null,error:{code:'AUTOSTART_QUERY_FAILED',message:'OS registry query failed: os_code=13'}};return value;
  269 |   };
  270 |  });
  271 |  await nav(page,'设置').click();await tab(page,'通知与启动').click();await expect(page.locator('.ns-os-status').first()).toContainText('已拒绝');await expect(page.locator('.ns-os-status').last()).toContainText('尚未确认');await expect(page.getByRole('alert')).toContainText('os_code=13');
  272 |  await tab(page,'关于').click();await tab(page,'通知与启动').click();expect(await calls(page,'notification_enable')).toEqual([]);expect(await calls(page,'autostart_set')).toEqual([]);
  273 | });
  274 | 
  275 | test('about shows a missing Bee version as unread while retaining the real build version',async({page})=>{
  276 |  await page.addInitScript(installAccountFixture,{runtimeEnabled:true,accounts:{openai:accountFixture('openai'),claude:accountFixture('claude')}});
  277 |  await page.addInitScript(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=(command:string,args:unknown)=>command==='bridge_status'?Promise.resolve({state:'failed',error:{code:'SIDECAR_EXIT',message:'owned management child exited: status=1'}}):invoke(command,args);});
  278 |  await page.goto('/');await nav(page,'设置').click();await tab(page,'关于').click();
  279 |  await expect(page.locator('.ns-core-version')).toContainText('尚未读取');await expect(page.getByRole('heading',{name:'Bee 0.1.0',exact:true})).toBeVisible();
  280 | });
  281 | 
  282 | for(const [width,height,language,theme] of [[1440,1000,'zh','light'],[1440,1000,'en','dark'],[860,600,'en','light'],[860,600,'zh','dark']] as const)test(`S2 tabs, dialogs and narrow layout remain usable at ${width} ${language} ${theme}`,async({page})=>{
  283 |  await page.setViewportSize({width,height});await setup(page);await nav(page,'设置').click();await tab(page,'通用').click();await page.getByLabel('外观',{exact:true}).selectOption(theme);await page.getByLabel('语言',{exact:true}).selectOption(language);
  284 |  const en=language==='en',networkTab=tab(page,en?'Network and proxy':'网络与代理');await expect(page.getByRole('status')).toHaveText(en?'Preferences saved.':'偏好已保存。');await networkTab.focus();await page.keyboard.press('End');await expect(tab(page,en?'About':'关于')).toHaveAttribute('aria-selected','true');await page.keyboard.press('Home');await expect(tab(page,en?'General':'通用')).toHaveAttribute('aria-selected','true');await page.keyboard.press('ArrowRight');await expect(networkTab).toHaveAttribute('aria-selected','true');
  285 |  const proxy=page.getByLabel(en?'Local HTTP proxy':'本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:7900');await expectPrimaryContrast(page,'.ns-network-actions .primary');await page.getByRole('button',{name:en?'Save proxy':'保存代理',exact:true}).click();
  286 |  await expect(page.locator('.ns-network-summary')).toContainText(en?'Proxy disabled':'代理未启用');
  287 |  const restart=page.getByRole('button',{name:en?'Stop and restart to apply':'停止并重新启动以应用',exact:true});await restart.click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(restart).toBeFocused();expect(await calls(page,'network_apply_saved')).toEqual([]);
  288 |  const networkShot=`settings-network-${theme}${en?'-en':''}-${width}`;await page.screenshot({path:`../.cache/s2-ui-verification/${networkShot}.png`});
  289 |  if(en&&width===1440){await page.setViewportSize({width:860,height:600});await page.screenshot({path:'../.cache/s2-ui-verification/settings-network-dark-en-860.png'});await page.locator('.ns-observed').scrollIntoViewIfNeeded();await page.screenshot({path:'../.cache/s2-ui-verification/settings-paths-dark-en-860.png'});await page.setViewportSize({width,height});}
  290 |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth)).toBe(true);
  291 |  await nav(page,en?'Diagnostics':'诊断').click();const checks=tab(page,en?'Check results':'检查结果');await checks.focus();await page.keyboard.press('ArrowRight');await expect(tab(page,en?'Safe logs':'安全日志')).toHaveAttribute('aria-selected','true');await page.keyboard.press('ArrowLeft');await expect(checks).toHaveAttribute('aria-selected','true');
  292 |  await expectPrimaryContrast(page,'.nd-actions .primary');await page.getByRole('button',{name:en?'Run diagnostics':'运行诊断',exact:true}).click();const exportButton=page.getByRole('button',{name:en?'Export sanitized report':'导出脱敏报告',exact:true});await exportButton.click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(exportButton).toBeFocused();
  293 |  expect(await calls(page,'diagnostics_export')).toEqual([]);expect(await calls(page,'diagnostic_logs')).toEqual([]);expect(await calls(page,'notification_enable')).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth)).toBe(true);
  294 |  await tab(page,en?'Safe logs':'安全日志').click();await page.getByRole('button',{name:en?'Refresh logs':'刷新日志',exact:true}).click();await expect(page.locator('.nd-log-list li')).toHaveCount(1);
  295 |  if(en)await page.setViewportSize({width:860,height:600});
  296 |  const logBounds=await page.locator('.nd-log-list li').first().evaluate(row=>{const range=document.createRange();range.selectNodeContents(row.querySelector('.nd-log-level')!);return {levelRight:range.getBoundingClientRect().right,codeLeft:row.querySelector('strong')!.getBoundingClientRect().left};});expect(logBounds.levelRight).toBeLessThanOrEqual(logBounds.codeLeft);
  297 |  if(en)await page.screenshot({path:`../.cache/s2-ui-verification/logs-${theme}-en-860.png`});
> 298 |  expect(await page.evaluate(async()=>[...(await import(/* @vite-ignore */ String('/src/i18n/index.ts'))).missingTranslations])).toEqual([]);
      |                                                                                                                                 ^ Error: expect(received).toEqual(expected) // deep equality
  299 | });
  300 | 
  301 | test('T8 original report read pauses after one failure and explicit reread completes without another start',async({page})=>{
  302 |  await setup(page);await nav(page,'诊断').click();
  303 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let failed=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='diagnostics_snapshot'&&!failed){failed=true;w.calls.push({command,args});throw {code:'IPC_TIMEOUT',message:'snapshot read timed out: report retained'};}return invoke(command,args);};});
  304 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
  305 |  await expect(page.getByText('报告读取已暂停，已返回的检查仍保留。',{exact:true})).toBeVisible();
  306 |  await expect(page.locator('.nd-report-meta')).toBeVisible();await page.clock.runFor(5000);expect((await calls(page,'diagnostics_snapshot')).length).toBe(1);
  307 |  await page.getByRole('button',{name:'重新读取原报告',exact:true}).click();await expect(page.getByText('检查已完成',{exact:true})).toBeVisible();
  308 |  expect((await calls(page,'diagnostics_start')).length).toBe(1);const reads=await calls(page,'diagnostics_snapshot');expect(new Set(reads.map((c:any)=>c.args.id)).size).toBe(1);
  309 |  await page.clock.runFor(5000);expect((await calls(page,'diagnostics_snapshot')).length).toBe(2);
  310 | });
  311 | test('T8 lost start receipt remains unknown across all pages and only logs are available without an ID',async({page})=>{
  312 |  await setup(page);await nav(page,'诊断').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_start')throw {code:'IPC_TIMEOUT',message:'start accepted; reply unavailable'};return result;};});
  313 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  314 |  for(const destination of ['概览','设置','AI 账号']){await nav(page,destination).click();await nav(page,'诊断').click();}
  315 |  await expect(page.getByText('诊断开始结果尚未确认；没有报告 ID，不能重新开始或查询原报告。',{exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'运行诊断',exact:true})).toBeDisabled();
  316 |  expect(await calls(page,'diagnostics_snapshot')).toEqual([]);expect((await calls(page,'diagnostics_start')).length).toBe(1);
  317 |  await tab(page,'安全日志').click();await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect(page.getByTestId('native-diagnostic-logs')).toBeVisible();
  318 | });
  319 | test('T8 lost cancel receipt is checked by original report reads across navigation',async({page})=>{
  320 |  await setup(page);await nav(page,'诊断').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.diagnosticsStayRunning=true;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_cancel')throw {code:'IPC_TIMEOUT',message:'cancel accepted; reply unavailable'};return result;};});
  321 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.getByRole('button',{name:'取消诊断',exact:true}).click();
  322 |  await nav(page,'设置').click();await nav(page,'诊断').click();await expect(page.getByText('取消结果尚未确认；仅核对原报告，不会重复取消。',{exact:true})).toBeVisible();
  323 |  await expect(page.getByRole('button',{name:'取消诊断',exact:true})).toBeDisabled();await page.getByRole('button',{name:'重新读取原报告',exact:true}).click();
  324 |  await expect(page.getByText('诊断已取消',{exact:true})).toBeVisible();expect((await calls(page,'diagnostics_cancel')).length).toBe(1);expect((await calls(page,'diagnostics_start')).length).toBe(1);
  325 | });
  326 | test('T8 saved proxy survives a failed network read and is never reported as a failed save',async({page})=>{
  327 |  await setup(page);await nav(page,'设置').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let saved=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='network_snapshot'&&saved){w.calls.push({command,args});throw {code:'NETWORK_RUNTIME_UNCONFIRMED',message:'network read unavailable after preference saved'};}const value=await invoke(command,args);if(command==='network_save_proxy')saved=true;return value;};});
  328 |  await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18381');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  329 |  await expect(page.getByText('代理配置已保存；生效状态尚未确认。',{exact:true})).toBeVisible();await expect(page.locator('.ns-network-summary')).toContainText('http://127.0.0.1:18381');
  330 |  await nav(page,'概览').click();await nav(page,'设置').click();await expect(page.getByText('代理配置已保存；生效状态尚未确认。',{exact:true})).toBeVisible();expect((await calls(page,'network_save_proxy')).length).toBe(1);
  331 | });
  332 | test('T8 unknown network apply preserves the draft and only rereads network and runtime after navigation',async({page})=>{
  333 |  await setup(page);await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18382');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  334 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='network_apply_saved')throw {code:'IPC_TIMEOUT',message:'apply accepted; reply lost'};return result;};});
  335 |  await page.getByRole('button',{name:'停止并重新启动以应用',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'停止并重新启动',exact:true}).click();
  336 |  await expect(page.getByText('应用请求结果尚未确认；只读取当前配置与运行状态，不会再次停止或应用。',{exact:true})).toBeVisible();
  337 |  for(const destination of ['诊断','AI 账号','概览']){await nav(page,destination).click();await nav(page,'设置').click();}
  338 |  await expect(page.getByText('应用请求结果尚未确认；只读取当前配置与运行状态，不会再次停止或应用。',{exact:true})).toBeVisible();await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toHaveValue('http://127.0.0.1:18382');
  339 |  await page.getByRole('button',{name:'刷新生效路径',exact:true}).click();expect((await calls(page,'network_apply_saved')).length).toBe(1);expect(await calls(page,'runtime_stop')).toEqual([]);expect(await calls(page,'runtime_start')).toEqual([]);
  340 | });
  341 | test('T8 denied notification keeps the saved preference and gives the actual OS settings location',async({page})=>{
  342 |  await setup(page);await page.evaluate(()=>{(window as any).notificationPermission='denied';});await nav(page,'设置').click();await tab(page,'通知与启动').click();
  343 |  await page.getByLabel(/^(希望接收系统通知|接收系统通知)$/).check();await expect(page.getByLabel(/^(希望接收系统通知|接收系统通知)$/)).toBeChecked();await expect(page.getByText('已拒绝',{exact:true})).toBeVisible();
  344 |  await expect(page.getByText('在 macOS“系统设置 → 通知 → Bee”中允许通知。应用内提醒会继续显示。',{exact:true})).toBeVisible();expect((await calls(page,'notification_enable')).length).toBe(1);
  345 | });
  346 | test('T8 autostart read failure retains the desired choice and actual registration receipt',async({page})=>{
  347 |  await setup(page);await nav(page,'设置').click();await tab(page,'通知与启动').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let changed=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='preferences_read'&&changed)throw {code:'PREFERENCES_READ_FAILED',message:'preferences read failed after autostart receipt'};const value=await invoke(command,args);if(command==='autostart_set')changed=true;return value;};});
  348 |  await page.getByLabel(/^(登录桌面后启动 Bee|登录系统后启动 Bee)$/).check();await expect(page.getByLabel(/^(登录桌面后启动 Bee|登录系统后启动 Bee)$/)).toBeChecked();await expect(page.getByText('已登记',{exact:true})).toBeVisible();
  349 |  await expect(page.getByText('系统登记回执已保留，偏好读取尚未确认。',{exact:true})).toBeVisible();await nav(page,'概览').click();await nav(page,'设置').click();await tab(page,'通知与启动').click();await expect(page.getByLabel(/^(登录桌面后启动 Bee|登录系统后启动 Bee)$/)).toBeChecked();expect((await calls(page,'autostart_set')).length).toBe(1);
  350 | });
  351 | 
  352 | 
  353 | test('T8 diagnostic local binding and revoked Hive identity remain separate concrete facts',async({page})=>{
  354 |  await setup(page);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const value=await invoke(command,args);if(command==='diagnostics_start'){const r=value.result.report;r.state='completed';r.finished_at=r.started_at;r.checks=[{id:'device',platform:null,status:'pass',code:'device_binding_valid',observed_at:r.started_at,evidence:{},next_action:'diagnostics'},{id:'hive',platform:null,status:'fail',code:'device_replaced',observed_at:r.started_at,evidence:{http_status:'401',server_code:'device_replaced'},next_action:'overview'}];}return value;};});
  355 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.getByTestId('passed-checks').locator(':scope > summary').click();
  356 |  await expect(page.getByText('本机绑定信息完整；远端身份需单独核对。',{exact:true})).toBeVisible();await expect(page.locator('.nd-issues')).toContainText('此设备已被替换，原设备凭据已撤销。');
  357 | });
  358 | 
  359 | test('T8 confirmed proxy save never selects an older device scope when its network read fails',async({page})=>{
  360 |  await setup(page);await nav(page,'设置').click();
  361 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let saved=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='network_snapshot'&&saved){w.calls.push({command,args});throw {code:'NETWORK_RUNTIME_UNCONFIRMED',message:'network observation unavailable after current-device save'};}const value=await invoke(command,args);if(command==='network_save_proxy'){saved=true;value.preferences.proxies.unshift({origin:'https://hive.example',device_scope:'previous-device',connect_proxy:'http://127.0.0.1:17001'});}return value;};});
  362 |  await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18389');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  363 |  const saved=page.locator('.ns-network-summary>div').first();await expect(saved).toContainText('http://127.0.0.1:18389');await expect(saved).not.toContainText('17001');
  364 |  await nav(page,'概览').click();await nav(page,'设置').click();await expect(saved).toContainText('http://127.0.0.1:18389');expect((await calls(page,'network_save_proxy')).length).toBe(1);
  365 | });
  366 | 
  367 | test('T8 unknown proxy save permits a new explicit save only after current scoped reads succeed',async({page})=>{
  368 |  await setup(page);await nav(page,'设置').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let lost=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const value=await invoke(command,args);if(command==='network_save_proxy'&&!lost){lost=true;throw {code:'IPC_TIMEOUT',message:'save accepted; receipt lost'};}return value;};});
  369 |  await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18391');const save=page.getByRole('button',{name:'保存代理',exact:true});await save.click();await expect(save).toBeDisabled();
  370 |  await page.getByRole('button',{name:'核对当前保存配置',exact:true}).click();await expect(save).toBeEnabled();expect((await calls(page,'network_save_proxy')).length).toBe(1);
  371 |  await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18392');await save.click();await expect(page.locator('.ns-network-summary')).toContainText('18392');expect((await calls(page,'network_save_proxy')).length).toBe(2);
  372 | });
  373 | 
  374 | test('T8 restore failure preserves the applied network and the separate stopped runtime',async({page})=>{
  375 |  await setup(page);await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18393');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  376 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const value=await invoke(command,args);if(command==='network_apply_saved')value.error={code:'RUNTIME_OPERATION_FAILED',message:'restore failed: local=stopped; intended=running',details:{check:'network_restore',observed_at:new Date().toISOString(),evidence:{}}};return value;};});
  377 |  await page.getByRole('button',{name:'停止并重新启动以应用',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'停止并重新启动',exact:true}).click();
  378 |  await expect(page.getByText('网络配置已生效，但贡献恢复未完成。',{exact:true})).toBeVisible();await expect(page.locator('.ns-network-summary>div').last()).toContainText('18393');await expect(page.getByText('当前贡献进程：已停止',{exact:true})).toBeVisible();
  379 |  await nav(page,'概览').click();await nav(page,'设置').click();await expect(page.getByText('网络配置已生效，但贡献恢复未完成。',{exact:true})).toBeVisible();expect((await calls(page,'network_apply_saved')).length).toBe(1);
  380 | });
  381 | 
  382 | test('T8 pending network apply receives one result after navigating away without replay',async({page})=>{
  383 |  await setup(page);await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18394');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  384 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const value=await invoke(command,args);if(command==='network_apply_saved')return new Promise(resolve=>w.releaseApply=()=>resolve(value));return value;};});
  385 |  await page.getByRole('button',{name:'停止并重新启动以应用',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'停止并重新启动',exact:true}).click();await expect.poll(()=>page.evaluate(()=>typeof (window as any).releaseApply)).toBe('function');
  386 |  await nav(page,'诊断').click();await nav(page,'设置').click();await expect(page.getByText('正在等待网络应用回执…',{exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'保存代理',exact:true})).toBeDisabled();
  387 |  await page.evaluate(()=>(window as any).releaseApply());await expect(page.getByText('已收到网络应用回执；贡献状态以当前读取为准。',{exact:true})).toBeVisible();expect((await calls(page,'network_apply_saved')).length).toBe(1);
  388 | });
  389 | 
  390 | test('T8 lost notification permission receipt survives navigation and is reconciled only by OS reads',async({page})=>{
  391 |  await setup(page);await nav(page,'设置').click();await tab(page,'通知与启动').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const value=await invoke(command,args);if(command==='notification_enable'){w.notificationPermission='granted';throw {code:'IPC_TIMEOUT',message:'notification permission receipt unavailable'};}return value;};});
  392 |  await page.getByLabel('接收系统通知',{exact:true}).check();await expect(page.getByText('通知授权请求结果尚未确认；请重新检查系统状态，不会重复请求授权。',{exact:true})).toBeVisible();
  393 |  await nav(page,'概览').click();await nav(page,'设置').click();await tab(page,'通知与启动').click();expect((await calls(page,'notification_enable')).length).toBe(1);
  394 |  await page.getByRole('button',{name:'重新检查系统状态',exact:true}).click();await expect(page.locator('.ns-os-status').first()).toContainText('已允许');expect((await calls(page,'notification_enable')).length).toBe(1);expect(await calls(page,'autostart_set')).toEqual([]);
  395 | });
  396 | 
  397 | test('T8 repeated original-report read failures preserve cancel evidence and share a pending reread',async({page})=>{
  398 |  await setup(page);await nav(page,'诊断').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.diagnosticsStayRunning=true;let reads=0;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='diagnostics_cancel'){w.calls.push({command,args});throw {code:'IPC_TIMEOUT',message:'cancel receipt missing: sent=true'};}if(command==='diagnostics_snapshot'){w.calls.push({command,args});if(++reads===1)throw {code:'IPC_TIMEOUT',message:'read failed: attempt=1'};return new Promise(resolve=>w.releaseRead=async()=>resolve(await invoke(command,args)));}return invoke(command,args);};});
```