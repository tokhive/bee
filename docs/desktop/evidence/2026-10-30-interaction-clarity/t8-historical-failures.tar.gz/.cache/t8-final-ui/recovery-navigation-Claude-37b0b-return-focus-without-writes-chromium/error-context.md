# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: recovery-navigation.spec.ts >> Claude inline source recovery keeps its platform, drafts and return focus without writes
- Location: tests/recovery-navigation.spec.ts:70:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'OpenAI 详情', exact: true })
    - locator resolved to <button type="button" data-size="icon" title="OpenAI 详情" data-slot="button" data-state="closed" data-variant="ghost" aria-expanded="false" aria-label="OpenAI 详情" aria-haspopup="dialog" class="ui-button quiet ">…</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <p id="radix-_r_f_">查看账号与额度，管理凭证读取方式。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <input placeholder="/tmp/claude" value="/tmp/claude-draft"/> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting 20ms
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <p>读取官方客户端已保存的登录；目录留空使用默认位置。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  2 × retrying click action
      - waiting 100ms
      - waiting for element to be visible, enabled and stable
      - element is visible, enabled and stable
      - scrolling into view if needed
      - done scrolling
      - <p id="radix-_r_f_">查看账号与额度，管理凭证读取方式。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  13 × retrying click action
       - waiting 500ms
       - waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <input placeholder="/tmp/claude" value="/tmp/claude-draft"/> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms
       - waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <p>读取官方客户端已保存的登录；目录留空使用默认位置。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms
       - waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <p id="radix-_r_f_">查看账号与额度，管理凭证读取方式。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
     - retrying click action
       - waiting 500ms
       - waiting for element to be visible, enabled and stable
       - element is visible, enabled and stable
       - scrolling into view if needed
       - done scrolling
       - <p id="radix-_r_f_">查看账号与额度，管理凭证读取方式。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting 500ms
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <input placeholder="/tmp/claude" value="/tmp/claude-draft"/> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting 500ms
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <p>读取官方客户端已保存的登录；目录留空使用默认位置。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting 500ms
    - waiting for element to be visible, enabled and stable
    - element is visible, enabled and stable
    - scrolling into view if needed
    - done scrolling
    - <p id="radix-_r_f_">查看账号与额度，管理凭证读取方式。</p> from <div role="dialog" tabindex="-1" id="radix-_r_d_" data-state="open" class="detail-sheet" aria-labelledby="radix-_r_e_" aria-describedby="radix-_r_f_">…</div> subtree intercepts pointer events
  - retrying click action
    - waiting 500ms

```

# Page snapshot

```yaml
- generic:
  - generic [aria-hidden]:
    - generic:
      - complementary:
        - generic: Bee
        - navigation:
          - button: 概览
          - button: AI 账号
          - button: 诊断
          - button: 设置
        - generic:
          - generic:
            - text: hive.example
            - paragraph: 尚未接入 AI 账号
          - generic:
            - generic:
              - text: Fixture
              - generic: 设备与平台控制
      - generic:
        - banner:
          - generic: 本机设备
        - main:
          - generic:
            - generic:
              - heading [level=1]: AI 账号
              - paragraph: 管理这台设备用于贡献的 AI 账号。
            - button: 打开 Hive 控制台
          - region:
            - generic:
              - heading [level=2]: AI 账号
              - generic: 0 个已接入
            - generic:
              - region:
                - generic:
                  - generic:
                    - generic:
                      - heading [level=3]: OpenAI
                    - paragraph: 尚未接入 OpenAI 账号
                    - paragraph: 不能接单
                    - paragraph: 已有登录，尚未接入
                    - list:
                      - listitem:
                        - text: Hive 未看到此平台的 Bee 连接
                        - paragraph: 请在概览核对贡献运行和实际连接原因。
                        - button: 查看连接
                - generic:
                  - generic:
                    - generic:
                      - generic: 额度
                      - generic: 尚未核对
                    - progressbar
                - generic:
                  - generic:
                    - button: 接入
                  - button
              - region:
                - generic:
                  - generic:
                    - generic [aria-hidden]: ✳
                  - generic:
                    - generic:
                      - heading [level=3]: Claude
                    - paragraph: 尚未接入 Claude 账号
                    - paragraph: 不能接单
                    - paragraph: 已有登录，尚未接入
                    - list:
                      - listitem:
                        - text: 已手动暂停
                        - paragraph: 恢复接单只解除此平台暂停；不会开始贡献，其他阻塞仍需满足。
                      - listitem:
                        - text: Hive 未看到此平台的 Bee 连接
                        - paragraph: 请在概览核对贡献运行和实际连接原因。
                        - button: 查看连接
                    - alert:
                      - paragraph: 没有读取所选凭证来源的权限。
                      - paragraph: 本次只确认了所选来源的读取结果，其他登录状态仍未知。
                      - button: 检查凭证来源
                      - group:
                        - generic: 查看失败详情
                - generic:
                  - generic:
                    - generic:
                      - generic: 额度
                      - generic: 尚未核对
                    - progressbar
                - generic:
                  - generic:
                    - button: 接入
                  - button [expanded]
            - paragraph: 授权信息保留在本机
        - contentinfo:
          - text: Bee
          - generic: 设备绑定不自动开始贡献
  - dialog [ref=e2]:
    - banner [ref=e3]:
      - heading "Claude 账号详情" [level=2] [ref=e4]
      - button "关闭" [active] [ref=e5] [cursor=pointer]
    - paragraph [ref=e6]: 查看账号与额度，管理凭证读取方式。
    - generic [ref=e7]:
      - generic [ref=e8]:
        - term [ref=e9]: 当前账号标识
        - definition [ref=e10]: 尚未接入 Claude 账号
      - generic [ref=e11]:
        - term [ref=e12]: 候选账号标识
        - definition [ref=e13]: 账号标识待官方核验
    - paragraph [ref=e14]: 已有登录，尚未接入
    - generic [ref=e15]:
      - heading "额度与重置" [level=3] [ref=e16]
      - generic [ref=e18]:
        - generic [ref=e19]:
          - generic [ref=e20]: 额度
          - generic [ref=e21]: 尚未核对
        - progressbar "已用额度" [ref=e22]
    - group [ref=e24]:
      - generic "凭证读取方式" [ref=e25] [cursor=pointer]
      - paragraph [ref=e26]: 读取官方客户端已保存的登录；目录留空使用默认位置。
      - generic [ref=e27]:
        - text: 自定义目录
        - textbox "自定义目录" [ref=e28]:
          - /placeholder: /tmp/claude
          - text: /tmp/claude-draft
      - generic [ref=e29]:
        - text: 存储方式
        - combobox "存储方式" [ref=e30]:
          - option "文件" [selected]
          - option "钥匙串"
      - paragraph [ref=e31]: 修改读取位置不会自动更换已接入账号。
    - generic [ref=e33]:
      - button "接入" [ref=e34] [cursor=pointer]
      - button "登录 Claude" [ref=e35] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {accountFixture,installAccountFixture} from './fixtures/native-accounts.mjs';
  3  | async function open(page:Page){await page.clock.install();await page.addInitScript(installAccountFixture,{runtimeEnabled:true,accounts:{openai:accountFixture('openai'),claude:accountFixture('claude')}});await page.goto('/');}
  4  | const nav=(page:Page,name:string)=>page.getByRole('navigation').getByRole('button',{name,exact:true});
  5  | const calls=(page:Page,command:string)=>page.evaluate(command=>(window as any).calls.filter((c:any)=>c.command===command).length,command);
  6  | 
  7  | for(const destination of ['概览','诊断','AI 账号'])test('settings draft survives a real page round trip through '+destination,async({page})=>{
  8  |  await open(page);await nav(page,'设置').click();const proxy=page.getByLabel('本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:18181');
  9  |  await nav(page,destination).click();await nav(page,'设置').click();await expect(proxy).toHaveValue('http://127.0.0.1:18181');
  10 |  expect(await calls(page,'network_save_proxy')).toBe(0);expect(await calls(page,'network_apply_saved')).toBe(0);expect(await calls(page,'diagnostics_start')).toBe(0);
  11 | });
  12 | test('binding replacement isolates unsaved settings drafts',async({page})=>{
  13 |  await open(page);await nav(page,'设置').click();const proxy=page.getByLabel('本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:18181');
  14 |  await page.evaluate(()=>(window as any).bindingRevision=2);await page.clock.runFor(10100);await expect(proxy).toHaveValue('');expect(await calls(page,'network_save_proxy')).toBe(0);
  15 | });
  16 | test('source repair navigates to a settings target and returns to the same platform draft',async({page})=>{
  17 |  await open(page);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(cmd:string,args:any)=>{if(cmd==='account_detect'&&args.request.platform==='openai')throw {code:'NETWORK_APPLY_REQUIRED',message:'saved network revision=3 effective=2',details:{check:'source_read',observed_at:new Date().toISOString(),evidence:{actual:'2',required:'3'}}};return invoke(cmd,args);};});
  18 |  await nav(page,'AI 账号').click();await page.getByRole('button',{name:'OpenAI 详情',exact:true}).click();
  19 |  const directory=page.getByRole('dialog').getByLabel('自定义目录',{exact:true});await directory.fill('/tmp/unsaved-source');await directory.press('Tab');
  20 |  await page.getByRole('dialog').getByRole('button',{name:'查看设置',exact:true}).first().click();
  21 |  await expect(page.getByRole('tab',{name:'网络与代理',exact:true})).toHaveAttribute('aria-selected','true');await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toBeFocused();
  22 |  await page.getByRole('button',{name:'返回原处',exact:true}).click();
  23 |  await expect(page.getByRole('dialog')).toBeVisible();await expect(directory).toHaveValue('/tmp/unsaved-source');await expect(directory).toBeFocused();
  24 |  expect(await calls(page,'network_save_proxy')).toBe(0);expect(await calls(page,'authorize_start')).toBe(0);expect(await calls(page,'account_action')).toBe(0);
  25 | });
  26 | test('unknown account result remains read only across navigation and a new instance clears the old operation',async({page})=>{
  27 |  await open(page);await nav(page,'AI 账号').click();const card=page.getByRole('region',{name:'OpenAI 账号',exact:true});await expect(card.getByRole('button',{name:'接入',exact:true})).toBeEnabled();
  28 |  await page.evaluate(()=>{(window as any).actionUnknown=true;});await card.getByRole('button',{name:'接入',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'确认接入',exact:true}).click();
  29 |  await expect.poll(()=>calls(page,'account_action')).toBe(1);await page.keyboard.press('Escape');await nav(page,'设置').click();await nav(page,'AI 账号').click();await page.clock.runFor(10100);expect(await calls(page,'account_action')).toBe(1);
  30 |  await page.evaluate(()=>{(window as any).actionUnknown=false;(window as any).emit('c'.repeat(32));});await page.clock.runFor(100);expect(await calls(page,'account_action')).toBe(1);
  31 | });
  32 | test('page navigation reveals the heading while background refresh preserves scroll and focus',async({page})=>{
  33 |  await page.setViewportSize({width:860,height:600});await open(page);await page.locator('main').evaluate(el=>el.scrollTop=el.scrollHeight);await nav(page,'诊断').click();
  34 |  const heading=page.getByRole('heading',{name:'诊断',exact:true,level:1});await expect(heading).toBeFocused();
  35 |  const bounds=await heading.boundingBox(),toolbar=await page.locator('.toolbar').boundingBox();expect(bounds!.y).toBeGreaterThanOrEqual(toolbar!.y+toolbar!.height);expect(await calls(page,'diagnostics_start')).toBe(0);
  36 |  await nav(page,'AI 账号').click();await page.locator('main').evaluate(el=>el.scrollTop=el.scrollHeight);const button=page.getByRole('button',{name:'Claude 详情',exact:true});await button.focus();
  37 |  const before=await page.locator('main').evaluate(el=>el.scrollTop);await page.clock.runFor(10100);await expect(button).toBeFocused();expect(await page.locator('main').evaluate(el=>el.scrollTop)).toBe(before);
  38 | });
  39 | 
  40 | test('a diagnostic report survives pages and a network change off-page invalidates it',async({page})=>{
  41 |  await open(page);await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
  42 |  await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeEnabled();
  43 |  for(const destination of ['概览','AI 账号','设置']){await nav(page,destination).click();await nav(page,'诊断').click();await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeEnabled();}
  44 |  expect(await calls(page,'diagnostics_start')).toBe(1);
  45 |  await nav(page,'AI 账号').click();await page.evaluate(()=>{(window as any).networkRevision=1;});await page.clock.runFor(10100);await nav(page,'诊断').click();
  46 |  await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeDisabled();expect(await calls(page,'diagnostics_start')).toBe(1);
  47 | });
  48 | 
  49 | test('a newer diagnostic identity rejection blocks account submission and runtime start',async({page})=>{
  50 |  await open(page);await nav(page,'AI 账号').click();const card=page.getByRole('region',{name:'OpenAI 账号',exact:true});await expect(card.getByRole('button',{name:'接入',exact:true})).toBeEnabled();
  51 |  await page.clock.runFor(100);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_start'||command==='diagnostics_snapshot'){result.result.report.checks[0]={...result.result.report.checks[0],status:'fail',code:'device_replaced',observed_at:new Date().toISOString(),evidence:{method:'GET',path:'/api/bee/identity',http_status:'401',server_code:'device_replaced'},next_action:'overview'};}return result;};});
  52 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
  53 |  await expect(page.getByText('此设备已被替换，原设备凭据已撤销。',{exact:true})).toBeVisible();await nav(page,'AI 账号').click();await expect(card.getByRole('button',{name:'接入',exact:true})).toBeDisabled();
  54 |  expect(await calls(page,'account_action')).toBe(0);expect(await calls(page,'runtime_start')).toBe(0);
  55 | });
  56 | 
  57 | test('a diagnostic target absent from a partial report focuses its summary once without starting a run',async({page})=>{
  58 |  await page.route('**/diagnostic-target-harness',route=>route.fulfill({contentType:'text/html',body:`<div id="harness"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;</script><script type="module">
  59 |  import React from '/node_modules/.vite/deps/react.js';import ReactDOM from '/node_modules/.vite/deps/react-dom_client.js';
  60 |  import {AppShell} from '/src/components/AppShell.tsx';import {NativeDiagnosticsPage} from '/src/features/diagnostics/NativeDiagnosticsPage.tsx';import '/src/styles/app.css';
  61 |  const report={id:'b'.repeat(48),instance:'a'.repeat(32),binding_revision:1,network_revision:0,run_id:null,state:'completed',started_at:new Date().toISOString(),finished_at:new Date().toISOString(),checks:[]};
  62 |  window.starts=0;const client={getSnapshot:()=>structuredClone(report),setContext:()=>{},getSession:()=>({start:'idle',cancel:'idle',read:'idle',failure:null,readFailure:null,download:'idle',downloadFailure:null}),subscribe:()=>()=>{},start:async()=>{window.starts++;return report;}};
  63 |  function Harness(){const [request,setRequest]=React.useState({target:{page:'diagnostics'},sequence:0}),[version,setVersion]=React.useState(0);window.addCheck=()=>{report.checks.push({id:'source',platform:'claude',status:'skipped',code:'not_checked',observed_at:new Date().toISOString(),evidence:{},next_action:'accounts'});setVersion(v=>v+1);};return React.createElement(AppShell,{page:'diagnostics',deviceMode:true,onNavigate:()=>{},navigationRequest:request},React.createElement('button',{onClick:()=>setRequest({target:{page:'diagnostics',section:'source',platform:'claude'},sequence:1})},'Locate Claude source'),React.createElement(NativeDiagnosticsPage,{key:version,client,instance:report.instance,bindingRevision:1,networkRevision:0,runId:null,navigationRequest:request,onNavigate:()=>{}}));}
  64 |  ReactDOM.createRoot(document.getElementById('harness')).render(React.createElement(Harness));</script>`}));
  65 |  await page.goto('/diagnostic-target-harness');await page.getByRole('button',{name:'Locate Claude source',exact:true}).click();
  66 |  const summary=page.locator('.nd-report-meta');await expect(summary).toBeFocused();expect(await page.evaluate(()=>(window as any).starts)).toBe(0);
  67 |  const heading=page.getByRole('heading',{level:1});await heading.focus();await page.evaluate(()=>(window as any).addCheck());await expect(page.locator('[data-nav-section="source"][data-nav-platform="claude"]')).toBeAttached();await expect(heading).toBeFocused();expect(await page.evaluate(()=>(window as any).starts)).toBe(0);
  68 | });
  69 | 
  70 | test('Claude inline source recovery keeps its platform, drafts and return focus without writes',async({page})=>{
  71 |  await open(page);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='account_detect'&&args.request.platform==='claude'){result.result.account.candidate.error={code:'permission_denied',check:'source_read',platform:'claude',message:'Claude fixture directory read denied',evidence:{permission_denied:'true'}};w.accounts.claude=result.result.account;}return result;};});
  72 |  await nav(page,'AI 账号').click();
  73 |  for(const [platform,draft] of [['OpenAI','/tmp/openai-draft'],['Claude','/tmp/claude-draft']]){
  74 |   await page.getByRole('button',{name:platform+' 详情',exact:true}).click();await page.getByRole('dialog').getByLabel('自定义目录',{exact:true}).fill(draft);await page.keyboard.press('Escape');
  75 |  }
  76 |  const row=page.getByRole('region',{name:'Claude 账号',exact:true});await row.getByRole('button',{name:'检查凭证来源',exact:true}).first().click();
  77 |  const dialog=page.getByRole('dialog');await expect(dialog).toHaveAccessibleName('Claude 账号详情');await expect(dialog.getByLabel('自定义目录',{exact:true})).toHaveValue('/tmp/claude-draft');await expect(dialog.getByLabel('自定义目录',{exact:true})).toBeFocused();
  78 |  await page.keyboard.press('Escape');await page.getByRole('button',{name:'返回原处',exact:true}).click();await expect(row).toBeFocused();
> 79 |  await page.getByRole('button',{name:'OpenAI 详情',exact:true}).click();await expect(page.getByRole('dialog').getByLabel('自定义目录',{exact:true})).toHaveValue('/tmp/openai-draft');
     |                                                               ^ Error: locator.click: Test timeout of 30000ms exceeded.
  80 |  for(const command of ['account_action','authorize_start','authorize_cancel','runtime_start','supply_set_paused'])expect(await calls(page,command)).toBe(0);
  81 | });
  82 | 
```