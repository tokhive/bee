# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: recovery-navigation.spec.ts >> a newer diagnostic identity rejection blocks account submission and runtime start
- Location: tests/recovery-navigation.spec.ts:49:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('此设备已被替换，原设备凭据已撤销。', { exact: true })
Expected: visible
Error: strict mode violation: getByText('此设备已被替换，原设备凭据已撤销。', { exact: true }) resolved to 2 elements:
    1) <p>此设备已被替换，原设备凭据已撤销。</p> aka getByRole('alert').getByText('此设备已被替换，原设备凭据已撤销。')
    2) <p>此设备已被替换，原设备凭据已撤销。</p> aka getByTestId('native-diagnostics').getByText('此设备已被替换，原设备凭据已撤销。')

Call log:
  - Expect "toBeVisible" getByText('此设备已被替换，原设备凭据已撤销。', { exact: true }) with timeout 5000ms
  - waiting for getByText('此设备已被替换，原设备凭据已撤销。', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]: Bee
    - navigation "主导航" [ref=e7]:
      - button "概览" [ref=e8] [cursor=pointer]
      - button "AI 账号" [ref=e12] [cursor=pointer]
      - button "诊断" [ref=e18] [cursor=pointer]
      - button "设置" [ref=e21] [cursor=pointer]
    - generic [ref=e25]:
      - generic [ref=e26]:
        - text: hive.example
        - paragraph [ref=e28]: 设备身份被拒绝
      - generic [ref=e33]:
        - text: Fixture
        - generic [ref=e34]: 设备与平台控制
  - generic [ref=e35]:
    - banner [ref=e36]:
      - generic [ref=e37]: 本机设备
    - main [ref=e41]:
      - generic [ref=e42]:
        - generic [ref=e43]:
          - heading "诊断" [level=1] [ref=e44]
          - paragraph [ref=e45]: 检查 Bee 运行与连接状态。
        - button "打开 Hive 控制台" [ref=e46] [cursor=pointer]
      - generic [ref=e47]:
        - alert [ref=e48]:
          - paragraph [ref=e49]: 此设备已被替换，原设备凭据已撤销。
          - paragraph [ref=e50]: 设备身份已失效，无法开始贡献；请先在 Hive 核对设备归属。
          - button "查看设备" [ref=e51] [cursor=pointer]
          - group [ref=e52]:
            - generic "查看失败详情" [ref=e53] [cursor=pointer]
        - button "重新检查设备" [ref=e54] [cursor=pointer]
      - generic [ref=e55]:
        - generic [ref=e56]:
          - tablist "诊断内容" [ref=e57]:
            - tab "检查结果" [selected] [ref=e58] [cursor=pointer]
            - tab "安全日志" [ref=e59] [cursor=pointer]
          - generic [ref=e60]:
            - button "重新运行诊断" [ref=e61] [cursor=pointer]
            - button "导出脱敏报告" [ref=e62] [cursor=pointer]
        - tabpanel "检查结果" [ref=e63]:
          - generic [ref=e64]:
            - generic [ref=e65]:
              - generic [ref=e66]: 检查已完成
              - time [ref=e67]: 2026年11月3日 00:03:39
            - generic [ref=e68]:
              - generic [ref=e69]:
                - text: 检查失败
                - strong [ref=e70]: "1"
              - generic [ref=e71]:
                - text: 需要留意
                - strong [ref=e72]: "0"
              - generic [ref=e73]:
                - text: 通过
                - strong [ref=e74]: "0"
              - generic [ref=e75]:
                - text: 未检查
                - strong [ref=e76]: "1"
          - region "需要处理的问题" [ref=e77]:
            - generic [ref=e78]:
              - heading "需要处理的问题" [level=2] [ref=e79]
              - generic [ref=e80]: "1"
            - generic [ref=e81]:
              - generic [ref=e82]:
                - heading "设备与连接" [level=3] [ref=e85]
                - generic [ref=e86]: "1"
              - list [ref=e87]:
                - listitem [ref=e88]:
                  - generic [ref=e89]:
                    - generic [ref=e90]:
                      - heading "Hive 连接" [level=3] [ref=e91]
                      - paragraph [ref=e92]: 此设备已被替换，原设备凭据已撤销。
                    - generic [ref=e93]: 检查失败
                  - generic [ref=e94]:
                    - group [ref=e95]:
                      - generic "检查详情" [ref=e96] [cursor=pointer]
                    - button "查看概览" [ref=e97] [cursor=pointer]
          - group [ref=e98]:
            - generic "尚未完成的检查1" [ref=e99] [cursor=pointer]
          - group [ref=e100]:
            - generic "通过的检查0" [ref=e101] [cursor=pointer]
      - group [ref=e102]:
        - generic "运行详情" [ref=e103]
    - contentinfo [ref=e104]:
      - text: Bee
      - generic [ref=e105]: 设备绑定不自动开始贡献
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {accountFixture,installAccountFixture} from './fixtures/native-accounts.mjs';
  3  | async function open(page:Page){await page.clock.install();await page.addInitScript(installAccountFixture,{runtimeEnabled:true,accounts:{openai:accountFixture('openai'),claude:accountFixture('claude')}});await page.goto('/');}
  4  | const nav=(page:Page,name:string)=>page.getByRole('navigation').getByRole('button',{name,exact:true});
  5  | const calls=(page:Page,command:string)=>page.evaluate(command=>(window as any).calls.filter((c:any)=>c.command===command).length,command);
  6  | 
  7  | for(const destination of ['概览','诊断','AI 账号'])test('settings draft survives a real page round trip through '+destination,async({page})=>{
  8  |  await open(page);await nav(page,'设置').click();const proxy=page.getByLabel('本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:18181');
  9  |  await nav(page,destination).click();await nav(page,'设置').click();await expect(proxy).toHaveValue('http://127.0.0.1:18181');
  10 |  expect(await calls(page,'network_save_proxy')).toBe(0);expect(await calls(page,'network_apply_saved')).toBe(0);expect(await calls(page,'diagnostics_start')).toBe(0);
  11 | });
  12 | test('binding replacement isolates unsaved settings drafts',async({page})=>{
  13 |  await open(page);await nav(page,'设置').click();const proxy=page.getByLabel('本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:18181');
  14 |  await page.evaluate(()=>(window as any).bindingRevision=2);await page.clock.runFor(10100);await expect(proxy).toHaveValue('');expect(await calls(page,'network_save_proxy')).toBe(0);
  15 | });
  16 | test('source repair navigates to a settings target and returns to the same platform draft',async({page})=>{
  17 |  await open(page);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(cmd:string,args:any)=>{if(cmd==='account_detect'&&args.request.platform==='openai')throw {code:'NETWORK_APPLY_REQUIRED',message:'saved network revision=3 effective=2',details:{check:'source_read',observed_at:new Date().toISOString(),evidence:{actual:'2',required:'3'}}};return invoke(cmd,args);};});
  18 |  await nav(page,'AI 账号').click();await page.getByRole('button',{name:'OpenAI 详情',exact:true}).click();
  19 |  const directory=page.getByRole('dialog').getByLabel('自定义目录',{exact:true});await directory.fill('/tmp/unsaved-source');await directory.press('Tab');
  20 |  await page.getByRole('dialog').getByRole('button',{name:'查看设置',exact:true}).first().click();
  21 |  await expect(page.getByRole('tab',{name:'网络与代理',exact:true})).toHaveAttribute('aria-selected','true');await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toBeFocused();
  22 |  await page.getByRole('button',{name:'返回原处',exact:true}).click();
  23 |  await expect(page.getByRole('dialog')).toBeVisible();await expect(directory).toHaveValue('/tmp/unsaved-source');await expect(directory).toBeFocused();
  24 |  expect(await calls(page,'network_save_proxy')).toBe(0);expect(await calls(page,'authorize_start')).toBe(0);expect(await calls(page,'account_action')).toBe(0);
  25 | });
  26 | test('unknown account result remains read only across navigation and a new instance clears the old operation',async({page})=>{
  27 |  await open(page);await nav(page,'AI 账号').click();const card=page.getByRole('region',{name:'OpenAI 账号',exact:true});await expect(card.getByRole('button',{name:'接入',exact:true})).toBeEnabled();
  28 |  await page.evaluate(()=>{(window as any).actionUnknown=true;});await card.getByRole('button',{name:'接入',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'确认接入',exact:true}).click();
  29 |  await expect.poll(()=>calls(page,'account_action')).toBe(1);await page.keyboard.press('Escape');await nav(page,'设置').click();await nav(page,'AI 账号').click();await page.clock.runFor(10100);expect(await calls(page,'account_action')).toBe(1);
  30 |  await page.evaluate(()=>{(window as any).actionUnknown=false;(window as any).emit('c'.repeat(32));});await page.clock.runFor(100);expect(await calls(page,'account_action')).toBe(1);
  31 | });
  32 | test('page navigation reveals the heading while background refresh preserves scroll and focus',async({page})=>{
  33 |  await page.setViewportSize({width:860,height:600});await open(page);await page.locator('main').evaluate(el=>el.scrollTop=el.scrollHeight);await nav(page,'诊断').click();
  34 |  const heading=page.getByRole('heading',{name:'诊断',exact:true,level:1});await expect(heading).toBeFocused();
  35 |  const bounds=await heading.boundingBox(),toolbar=await page.locator('.toolbar').boundingBox();expect(bounds!.y).toBeGreaterThanOrEqual(toolbar!.y+toolbar!.height);expect(await calls(page,'diagnostics_start')).toBe(0);
  36 |  await nav(page,'AI 账号').click();await page.locator('main').evaluate(el=>el.scrollTop=el.scrollHeight);const button=page.getByRole('button',{name:'Claude 详情',exact:true});await button.focus();
  37 |  const before=await page.locator('main').evaluate(el=>el.scrollTop);await page.clock.runFor(10100);await expect(button).toBeFocused();expect(await page.locator('main').evaluate(el=>el.scrollTop)).toBe(before);
  38 | });
  39 | 
  40 | test('a diagnostic report survives pages and a network change off-page invalidates it',async({page})=>{
  41 |  await open(page);await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
  42 |  await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeEnabled();
  43 |  for(const destination of ['概览','AI 账号','设置']){await nav(page,destination).click();await nav(page,'诊断').click();await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeEnabled();}
  44 |  expect(await calls(page,'diagnostics_start')).toBe(1);
  45 |  await nav(page,'AI 账号').click();await page.evaluate(()=>{(window as any).networkRevision=1;});await page.clock.runFor(10100);await nav(page,'诊断').click();
  46 |  await expect(page.getByRole('button',{name:'导出脱敏报告',exact:true})).toBeDisabled();expect(await calls(page,'diagnostics_start')).toBe(1);
  47 | });
  48 | 
  49 | test('a newer diagnostic identity rejection blocks account submission and runtime start',async({page})=>{
  50 |  await open(page);await nav(page,'AI 账号').click();const card=page.getByRole('region',{name:'OpenAI 账号',exact:true});await expect(card.getByRole('button',{name:'接入',exact:true})).toBeEnabled();
  51 |  await page.clock.runFor(100);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_start'||command==='diagnostics_snapshot'){result.result.report.checks[0]={...result.result.report.checks[0],status:'fail',code:'device_replaced',observed_at:new Date().toISOString(),evidence:{method:'GET',path:'/api/bee/identity',http_status:'401',server_code:'device_replaced'},next_action:'overview'};}return result;};});
  52 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
> 53 |  await expect(page.getByText('此设备已被替换，原设备凭据已撤销。',{exact:true})).toBeVisible();await nav(page,'AI 账号').click();await expect(card.getByRole('button',{name:'接入',exact:true})).toBeDisabled();
     |                                                                 ^ Error: expect(locator).toBeVisible() failed
  54 |  expect(await calls(page,'account_action')).toBe(0);expect(await calls(page,'runtime_start')).toBe(0);
  55 | });
  56 | 
  57 | test('a diagnostic target absent from a partial report focuses its summary once without starting a run',async({page})=>{
  58 |  await page.route('**/diagnostic-target-harness',route=>route.fulfill({contentType:'text/html',body:`<div id="harness"></div><script type="module">import RefreshRuntime from "/@react-refresh";RefreshRuntime.injectIntoGlobalHook(window);window.$RefreshReg$=()=>{};window.$RefreshSig$=()=>type=>type;window.__vite_plugin_react_preamble_installed__=true;</script><script type="module">
  59 |  import React from '/node_modules/.vite/deps/react.js';import ReactDOM from '/node_modules/.vite/deps/react-dom_client.js';
  60 |  import {AppShell} from '/src/components/AppShell.tsx';import {NativeDiagnosticsPage} from '/src/features/diagnostics/NativeDiagnosticsPage.tsx';import '/src/styles/app.css';
  61 |  const report={id:'b'.repeat(48),instance:'a'.repeat(32),binding_revision:1,network_revision:0,run_id:null,state:'completed',started_at:new Date().toISOString(),finished_at:new Date().toISOString(),checks:[]};
  62 |  window.starts=0;const client={getSnapshot:()=>structuredClone(report),setContext:()=>{},getSession:()=>({start:'idle',cancel:'idle',read:'idle',failure:null,readFailure:null,download:'idle',downloadFailure:null}),subscribe:()=>()=>{},start:async()=>{window.starts++;return report;}};
  63 |  function Harness(){const [request,setRequest]=React.useState({target:{page:'diagnostics'},sequence:0}),[version,setVersion]=React.useState(0);window.addCheck=()=>{report.checks.push({id:'source',platform:'claude',status:'skipped',code:'not_checked',observed_at:new Date().toISOString(),evidence:{},next_action:'accounts'});setVersion(v=>v+1);};return React.createElement(AppShell,{page:'diagnostics',deviceMode:true,onNavigate:()=>{},navigationRequest:request},React.createElement('button',{onClick:()=>setRequest({target:{page:'diagnostics',section:'source',platform:'claude'},sequence:1})},'Locate Claude source'),React.createElement(NativeDiagnosticsPage,{key:version,client,instance:report.instance,bindingRevision:1,networkRevision:0,runId:null,navigationRequest:request,onNavigate:()=>{}}));}
  64 |  ReactDOM.createRoot(document.getElementById('harness')).render(React.createElement(Harness));</script>`}));
  65 |  await page.goto('/diagnostic-target-harness');await page.getByRole('button',{name:'Locate Claude source',exact:true}).click();
  66 |  const summary=page.locator('.nd-report-meta');await expect(summary).toBeFocused();expect(await page.evaluate(()=>(window as any).starts)).toBe(0);
  67 |  const heading=page.getByRole('heading',{level:1});await heading.focus();await page.evaluate(()=>(window as any).addCheck());await expect(page.locator('[data-nav-section="source"][data-nav-platform="claude"]')).toBeAttached();await expect(heading).toBeFocused();expect(await page.evaluate(()=>(window as any).starts)).toBe(0);
  68 | });
  69 | 
  70 | test('Claude inline source recovery keeps its platform, drafts and return focus without writes',async({page})=>{
  71 |  await open(page);await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='account_detect'&&args.request.platform==='claude'){result.result.account.candidate.error={code:'permission_denied',check:'source_read',platform:'claude',message:'Claude fixture directory read denied',evidence:{permission_denied:'true'}};w.accounts.claude=result.result.account;}return result;};});
  72 |  await nav(page,'AI 账号').click();
  73 |  for(const [platform,draft] of [['OpenAI','/tmp/openai-draft'],['Claude','/tmp/claude-draft']]){
  74 |   await page.getByRole('button',{name:platform+' 详情',exact:true}).click();await page.getByRole('dialog').getByLabel('自定义目录',{exact:true}).fill(draft);await page.keyboard.press('Escape');
  75 |  }
  76 |  const row=page.getByRole('region',{name:'Claude 账号',exact:true});await row.getByRole('button',{name:'检查凭证来源',exact:true}).first().click();
  77 |  const dialog=page.getByRole('dialog');await expect(dialog).toHaveAccessibleName('Claude 账号详情');await expect(dialog.getByLabel('自定义目录',{exact:true})).toHaveValue('/tmp/claude-draft');await expect(dialog.getByLabel('自定义目录',{exact:true})).toBeFocused();
  78 |  await page.keyboard.press('Escape');await page.getByRole('button',{name:'返回原处',exact:true}).click();await expect(row).toBeFocused();
  79 |  await page.getByRole('button',{name:'OpenAI 详情',exact:true}).click();await expect(page.getByRole('dialog').getByLabel('自定义目录',{exact:true})).toHaveValue('/tmp/openai-draft');
  80 |  for(const command of ['account_action','authorize_start','authorize_cancel','runtime_start','supply_set_paused'])expect(await calls(page,command)).toBe(0);
  81 | });
  82 | 
```