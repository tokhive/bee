# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: native-experience.spec.ts >> T8 original report read pauses after one failure and explicit reread completes without another start
- Location: tests/native-experience.spec.ts:301:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('报告读取已暂停，已返回的检查仍保留。', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('报告读取已暂停，已返回的检查仍保留。', { exact: true }) with timeout 5000ms
  - waiting for getByText('报告读取已暂停，已返回的检查仍保留。', { exact: true })

```

```yaml
- complementary:
  - text: Bee
  - navigation "主导航":
    - button "概览"
    - button "AI 账号"
    - button "诊断"
    - button "设置"
  - text: hive.example
  - paragraph: 尚未接入 AI 账号
  - text: Fixture 设备与平台控制
- banner: 本机设备
- main:
  - heading "诊断" [level=1]
  - paragraph: 检查 Bee 运行与连接状态。
  - button "打开 Hive 控制台"
  - tablist "诊断内容":
    - tab "检查结果" [selected]
    - tab "安全日志"
  - button "重新运行诊断" [disabled]
  - button "取消诊断"
  - button "导出脱敏报告"
  - alert:
    - paragraph: 本次操作失败，原因尚未确认。
    - paragraph: 本次操作未能完成；后续状态以重新核对的结果为准。
    - group: 查看失败详情
  - tabpanel "检查结果":
    - text: 诊断进行中
    - time: 2026年11月2日 23:37:43
    - text: 检查失败
    - strong: "0"
    - text: 需要留意
    - strong: "0"
    - text: 通过
    - strong: "1"
    - text: 未检查
    - strong: "1"
    - paragraph: 检查仍在进行，尚不能确认全部结果。
    - group: 尚未完成的检查1
    - group: 通过的检查1
  - group: 核对诊断
- contentinfo: Bee 设备绑定不自动开始贡献
```

# Test source

```ts
  205 |  });
  206 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  207 |  const issues=page.locator('.nd-issues');await expect(issues.locator('li')).toHaveCount(4);
  208 |  await expect(issues.getByText('官方授权已失效',{exact:true})).toBeVisible();await expect(issues.getByText('订阅额度已耗尽',{exact:true})).toBeVisible();await expect(issues.getByText('账号在检查期间发生变化',{exact:true})).toBeVisible();
  209 |  await issues.locator('li').first().locator('summary').click();await expect(issues.locator('li').first()).toContainText('connection_failed');await expect(issues.locator('dd').first()).toHaveText('409');
  210 |  await page.getByTestId('unfinished-checks').locator(':scope > summary').click();await page.getByTestId('passed-checks').locator(':scope > summary').click();
  211 |  await expect(page.locator('.nd-checks>li')).toHaveCount(6);await expect(page.getByText('尚未选择此平台的账号',{exact:true})).toBeVisible();await expect(page.getByText('Hive 身份已核对',{exact:true})).toBeVisible();await expect(page.getByText('全部检查通过',{exact:true})).toHaveCount(0);
  212 |  await issues.getByRole('button',{name:'查看设置',exact:true}).click();await expect(tab(page,'网络与代理')).toHaveAttribute('aria-selected','true');
  213 | });
  214 | 
  215 | for(const scenario of ['empty','skipped','cancelled','passed','unknown'] as const)test(`diagnostic summary distinguishes ${scenario} reports`,async({page})=>{
  216 |  await setup(page);await page.evaluate(scenario=>{
  217 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;
  218 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  219 |    const reply=await invoke(command,args);if(command!=='diagnostics_start')return reply;
  220 |    const report=reply.result.report;report.state=scenario==='cancelled'?'cancelled':'completed';report.finished_at=report.started_at;
  221 |    report.checks=scenario==='empty'?[]:scenario==='skipped'?[report.checks[1]]:[report.checks[0]];
  222 |    if(scenario==='unknown')report.checks=[{...report.checks[0],status:'skipped',code:'not_checked'}];return reply;
  223 |   };
  224 |  },scenario);
  225 |  await nav(page,'诊断').click();await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  226 |  await expect(page.getByText(scenario==='cancelled'?'诊断已取消':'检查已完成',{exact:true})).toBeVisible();
  227 |  await expect(page.getByText('全部检查通过',{exact:true})).toHaveCount(scenario==='passed'?1:0);
  228 |  await expect(page.locator('.nd-checks>li')).toHaveCount(scenario==='empty'?0:1);
  229 | });
  230 | 
  231 | test('log filters distinguish unread and empty and reject a late result from an older filter',async({page})=>{
  232 |  await setup(page);await page.evaluate(()=>{
  233 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let reads=0;
  234 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  235 |    const reply=await invoke(command,args);if(command!=='diagnostic_logs')return reply;
  236 |    if(++reads===1)return new Promise(resolve=>{w.releaseLogs=()=>resolve(reply);});
  237 |    return {entries:[],next_cursor:null,truncated:false};
  238 |   };
  239 |  });
  240 |  await nav(page,'诊断').click();await tab(page,'安全日志').click();
  241 |  await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();
  242 |  await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect.poll(async()=>(await calls(page,'diagnostic_logs')).length).toBe(1);
  243 |  await page.getByLabel(/^模块/).selectOption('network');await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();
  244 |  await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect(page.getByText('所选范围没有保留的安全事件。',{exact:true})).toBeVisible();
  245 |  await page.evaluate(()=>{(window as any).releaseLogs();});await expect(page.getByText('所选范围没有保留的安全事件。',{exact:true})).toBeVisible();
  246 |  await expect(page.locator('.nd-log-list li')).toHaveCount(0);
  247 |  await page.getByLabel(/^平台/).selectOption('claude');await expect(page.getByText('点击刷新日志，查看所选范围的安全事件。',{exact:true})).toBeVisible();expect((await calls(page,'diagnostic_logs')).length).toBe(2);
  248 | });
  249 | 
  250 | test('older initial network observation cannot replace an explicit refresh or an edited proxy',async({page})=>{
  251 |  await setup(page);await page.evaluate(()=>{
  252 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let reads=0;
  253 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  254 |    const reply=await invoke(command,args);if(command!=='network_snapshot'||++reads!==1)return reply;
  255 |    return new Promise(resolve=>{w.releaseNetwork=()=>resolve({...reply,saved_proxy:'http://127.0.0.1:7801',effective_proxy:'http://127.0.0.1:7801'});});
  256 |   };
  257 |  });
  258 |  await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:7900');
  259 |  await page.getByRole('button',{name:'刷新生效路径',exact:true}).click();await expect(page.locator('.ns-network-summary')).toContainText('代理未启用');
  260 |  await page.evaluate(()=>{(window as any).releaseNetwork();});await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toHaveValue('http://127.0.0.1:7900');await expect(page.locator('.ns-network-summary')).not.toContainText('7801');
  261 | });
  262 | 
  263 | test('denied notifications and unknown autostart remain distinct without requesting OS changes',async({page})=>{
  264 |  await setup(page);await page.evaluate(()=>{
  265 |   const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;
  266 |   w.__TAURI_INTERNALS__.invoke=async(command:string,args:unknown)=>{
  267 |    const value=await invoke(command,args);if(command==='notification_permission')return 'denied';
  268 |    if(command==='autostart_status')return {desired:false,registered:null,error:{code:'AUTOSTART_QUERY_FAILED',message:'OS registry query failed: os_code=13'}};return value;
  269 |   };
  270 |  });
  271 |  await nav(page,'设置').click();await tab(page,'通知与启动').click();await expect(page.locator('.ns-os-status').first()).toContainText('已拒绝');await expect(page.locator('.ns-os-status').last()).toContainText('尚未确认');await expect(page.getByRole('alert')).toContainText('os_code=13');
  272 |  await tab(page,'关于').click();await tab(page,'通知与启动').click();expect(await calls(page,'notification_enable')).toEqual([]);expect(await calls(page,'autostart_set')).toEqual([]);
  273 | });
  274 | 
  275 | test('about shows a missing Bee version as unread while retaining the real build version',async({page})=>{
  276 |  await page.addInitScript(installAccountFixture,{runtimeEnabled:true,accounts:{openai:accountFixture('openai'),claude:accountFixture('claude')}});
  277 |  await page.addInitScript(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=(command:string,args:unknown)=>command==='bridge_status'?Promise.resolve({state:'failed',error:{code:'SIDECAR_EXIT',message:'owned management child exited: status=1'}}):invoke(command,args);});
  278 |  await page.goto('/');await nav(page,'设置').click();await tab(page,'关于').click();
  279 |  await expect(page.locator('.ns-core-version')).toContainText('尚未读取');await expect(page.getByRole('heading',{name:'Bee 0.1.0',exact:true})).toBeVisible();
  280 | });
  281 | 
  282 | for(const [width,height,language,theme] of [[1440,1000,'zh','light'],[1440,1000,'en','dark'],[860,600,'en','light'],[860,600,'zh','dark']] as const)test(`S2 tabs, dialogs and narrow layout remain usable at ${width} ${language} ${theme}`,async({page})=>{
  283 |  await page.setViewportSize({width,height});await setup(page);await nav(page,'设置').click();await tab(page,'通用').click();await page.getByLabel('外观',{exact:true}).selectOption(theme);await page.getByLabel('语言',{exact:true}).selectOption(language);
  284 |  const en=language==='en',networkTab=tab(page,en?'Network and proxy':'网络与代理');await expect(page.getByRole('status')).toHaveText(en?'Preferences saved.':'偏好已保存。');await networkTab.focus();await page.keyboard.press('End');await expect(tab(page,en?'About':'关于')).toHaveAttribute('aria-selected','true');await page.keyboard.press('Home');await expect(tab(page,en?'General':'通用')).toHaveAttribute('aria-selected','true');await page.keyboard.press('ArrowRight');await expect(networkTab).toHaveAttribute('aria-selected','true');
  285 |  const proxy=page.getByLabel(en?'Local HTTP proxy':'本机 HTTP 代理',{exact:true});await proxy.fill('http://127.0.0.1:7900');await expectPrimaryContrast(page,'.ns-network-actions .primary');await page.getByRole('button',{name:en?'Save proxy':'保存代理',exact:true}).click();
  286 |  await expect(page.locator('.ns-network-summary')).toContainText(en?'Proxy disabled':'代理未启用');
  287 |  const restart=page.getByRole('button',{name:en?'Stop and restart to apply':'停止并重新启动以应用',exact:true});await restart.click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(restart).toBeFocused();expect(await calls(page,'network_apply_saved')).toEqual([]);
  288 |  const networkShot=`settings-network-${theme}${en?'-en':''}-${width}`;await page.screenshot({path:`../.cache/s2-ui-verification/${networkShot}.png`});
  289 |  if(en&&width===1440){await page.setViewportSize({width:860,height:600});await page.screenshot({path:'../.cache/s2-ui-verification/settings-network-dark-en-860.png'});await page.locator('.ns-observed').scrollIntoViewIfNeeded();await page.screenshot({path:'../.cache/s2-ui-verification/settings-paths-dark-en-860.png'});await page.setViewportSize({width,height});}
  290 |  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth)).toBe(true);
  291 |  await nav(page,en?'Diagnostics':'诊断').click();const checks=tab(page,en?'Check results':'检查结果');await checks.focus();await page.keyboard.press('ArrowRight');await expect(tab(page,en?'Safe logs':'安全日志')).toHaveAttribute('aria-selected','true');await page.keyboard.press('ArrowLeft');await expect(checks).toHaveAttribute('aria-selected','true');
  292 |  await expectPrimaryContrast(page,'.nd-actions .primary');await page.getByRole('button',{name:en?'Run diagnostics':'运行诊断',exact:true}).click();const exportButton=page.getByRole('button',{name:en?'Export sanitized report':'导出脱敏报告',exact:true});await exportButton.click();await expect(page.getByRole('dialog')).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('dialog')).toHaveCount(0);await expect(exportButton).toBeFocused();
  293 |  expect(await calls(page,'diagnostics_export')).toEqual([]);expect(await calls(page,'diagnostic_logs')).toEqual([]);expect(await calls(page,'notification_enable')).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth)).toBe(true);
  294 |  await tab(page,en?'Safe logs':'安全日志').click();await page.getByRole('button',{name:en?'Refresh logs':'刷新日志',exact:true}).click();await expect(page.locator('.nd-log-list li')).toHaveCount(1);
  295 |  if(en)await page.setViewportSize({width:860,height:600});
  296 |  const logBounds=await page.locator('.nd-log-list li').first().evaluate(row=>{const range=document.createRange();range.selectNodeContents(row.querySelector('.nd-log-level')!);return {levelRight:range.getBoundingClientRect().right,codeLeft:row.querySelector('strong')!.getBoundingClientRect().left};});expect(logBounds.levelRight).toBeLessThanOrEqual(logBounds.codeLeft);
  297 |  if(en)await page.screenshot({path:`../.cache/s2-ui-verification/logs-${theme}-en-860.png`});
  298 |  expect(await page.evaluate(async()=>[...(await import(/* @vite-ignore */ String('/src/i18n/index.ts'))).missingTranslations])).toEqual([]);
  299 | });
  300 | 
  301 | test('T8 original report read pauses after one failure and explicit reread completes without another start',async({page})=>{
  302 |  await setup(page);await nav(page,'诊断').click();
  303 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let failed=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='diagnostics_snapshot'&&!failed){failed=true;w.calls.push({command,args});throw {code:'IPC_TIMEOUT',message:'snapshot read timed out: report retained'};}return invoke(command,args);};});
  304 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.clock.runFor(900);
> 305 |  await expect(page.getByText('报告读取已暂停，已返回的检查仍保留。',{exact:true})).toBeVisible();
      |                                                                  ^ Error: expect(locator).toBeVisible() failed
  306 |  await expect(page.locator('.nd-report-meta')).toBeVisible();await page.clock.runFor(5000);expect((await calls(page,'diagnostics_snapshot')).length).toBe(1);
  307 |  await page.getByRole('button',{name:'重新读取原报告',exact:true}).click();await expect(page.getByText('检查已完成',{exact:true})).toBeVisible();
  308 |  expect((await calls(page,'diagnostics_start')).length).toBe(1);const reads=await calls(page,'diagnostics_snapshot');expect(new Set(reads.map((c:any)=>c.args.id)).size).toBe(1);
  309 |  await page.clock.runFor(5000);expect((await calls(page,'diagnostics_snapshot')).length).toBe(2);
  310 | });
  311 | test('T8 lost start receipt remains unknown across all pages and only logs are available without an ID',async({page})=>{
  312 |  await setup(page);await nav(page,'诊断').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_start')throw {code:'IPC_TIMEOUT',message:'start accepted; reply unavailable'};return result;};});
  313 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();
  314 |  for(const destination of ['概览','设置','AI 账号']){await nav(page,destination).click();await nav(page,'诊断').click();}
  315 |  await expect(page.getByText('诊断开始结果尚未确认；没有报告 ID，不能重新开始或查询原报告。',{exact:true})).toBeVisible();await expect(page.getByRole('button',{name:'运行诊断',exact:true})).toBeDisabled();
  316 |  expect(await calls(page,'diagnostics_snapshot')).toEqual([]);expect((await calls(page,'diagnostics_start')).length).toBe(1);
  317 |  await tab(page,'安全日志').click();await page.getByRole('button',{name:'刷新日志',exact:true}).click();await expect(page.getByTestId('native-diagnostic-logs')).toBeVisible();
  318 | });
  319 | test('T8 lost cancel receipt is checked by original report reads across navigation',async({page})=>{
  320 |  await setup(page);await nav(page,'诊断').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.diagnosticsStayRunning=true;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='diagnostics_cancel')throw {code:'IPC_TIMEOUT',message:'cancel accepted; reply unavailable'};return result;};});
  321 |  await page.getByRole('button',{name:'运行诊断',exact:true}).click();await page.getByRole('button',{name:'取消诊断',exact:true}).click();
  322 |  await nav(page,'设置').click();await nav(page,'诊断').click();await expect(page.getByText('取消结果尚未确认；仅核对原报告，不会重复取消。',{exact:true})).toBeVisible();
  323 |  await expect(page.getByRole('button',{name:'取消诊断',exact:true})).toBeDisabled();await page.getByRole('button',{name:'重新读取原报告',exact:true}).click();
  324 |  await expect(page.getByText('诊断已取消',{exact:true})).toBeVisible();expect((await calls(page,'diagnostics_cancel')).length).toBe(1);expect((await calls(page,'diagnostics_start')).length).toBe(1);
  325 | });
  326 | test('T8 saved proxy survives a failed network read and is never reported as a failed save',async({page})=>{
  327 |  await setup(page);await nav(page,'设置').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let saved=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='network_snapshot'&&saved){w.calls.push({command,args});throw {code:'NETWORK_RUNTIME_UNCONFIRMED',message:'network read unavailable after preference saved'};}const value=await invoke(command,args);if(command==='network_save_proxy')saved=true;return value;};});
  328 |  await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18381');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  329 |  await expect(page.getByText('代理配置已保存；生效状态尚未确认。',{exact:true})).toBeVisible();await expect(page.locator('.ns-network-summary')).toContainText('http://127.0.0.1:18381');
  330 |  await nav(page,'概览').click();await nav(page,'设置').click();await expect(page.getByText('代理配置已保存；生效状态尚未确认。',{exact:true})).toBeVisible();expect((await calls(page,'network_save_proxy')).length).toBe(1);
  331 | });
  332 | test('T8 unknown network apply preserves the draft and only rereads network and runtime after navigation',async({page})=>{
  333 |  await setup(page);await nav(page,'设置').click();await page.getByLabel('本机 HTTP 代理',{exact:true}).fill('http://127.0.0.1:18382');await page.getByRole('button',{name:'保存代理',exact:true}).click();
  334 |  await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{const result=await invoke(command,args);if(command==='network_apply_saved')throw {code:'IPC_TIMEOUT',message:'apply accepted; reply lost'};return result;};});
  335 |  await page.getByRole('button',{name:'停止并重新启动以应用',exact:true}).click();await page.getByRole('dialog').getByRole('button',{name:'停止并重新启动',exact:true}).click();
  336 |  await expect(page.getByText('应用请求结果尚未确认；只读取当前配置与运行状态，不会再次停止或应用。',{exact:true})).toBeVisible();
  337 |  for(const destination of ['诊断','AI 账号','概览']){await nav(page,destination).click();await nav(page,'设置').click();}
  338 |  await expect(page.getByText('应用请求结果尚未确认；只读取当前配置与运行状态，不会再次停止或应用。',{exact:true})).toBeVisible();await expect(page.getByLabel('本机 HTTP 代理',{exact:true})).toHaveValue('http://127.0.0.1:18382');
  339 |  await page.getByRole('button',{name:'刷新生效路径',exact:true}).click();expect((await calls(page,'network_apply_saved')).length).toBe(1);expect(await calls(page,'runtime_stop')).toEqual([]);expect(await calls(page,'runtime_start')).toEqual([]);
  340 | });
  341 | test('T8 denied notification keeps the saved preference and gives the actual OS settings location',async({page})=>{
  342 |  await setup(page);await page.evaluate(()=>{(window as any).notificationPermission='denied';});await nav(page,'设置').click();await tab(page,'通知与启动').click();
  343 |  await page.getByLabel('接收系统通知',{exact:true}).check();await expect(page.getByLabel('接收系统通知',{exact:true})).toBeChecked();await expect(page.getByText('已拒绝',{exact:true})).toBeVisible();
  344 |  await expect(page.getByText('在 macOS“系统设置 → 通知 → Bee”中允许通知。应用内提醒会继续显示。',{exact:true})).toBeVisible();expect((await calls(page,'notification_enable')).length).toBe(1);
  345 | });
  346 | test('T8 autostart read failure retains the desired choice and actual registration receipt',async({page})=>{
  347 |  await setup(page);await nav(page,'设置').click();await tab(page,'通知与启动').click();await page.evaluate(()=>{const w=window as any,invoke=w.__TAURI_INTERNALS__.invoke;let changed=false;w.__TAURI_INTERNALS__.invoke=async(command:string,args:any)=>{if(command==='preferences_read'&&changed)throw {code:'PREFERENCES_READ_FAILED',message:'preferences read failed after autostart receipt'};const value=await invoke(command,args);if(command==='autostart_set')changed=true;return value;};});
  348 |  await page.getByLabel('登录系统后启动 Bee',{exact:true}).check();await expect(page.getByLabel('登录系统后启动 Bee',{exact:true})).toBeChecked();await expect(page.getByText('已登记',{exact:true})).toBeVisible();
  349 |  await expect(page.getByText('系统登记回执已保留，偏好读取尚未确认。',{exact:true})).toBeVisible();await nav(page,'概览').click();await nav(page,'设置').click();await tab(page,'通知与启动').click();await expect(page.getByLabel('登录系统后启动 Bee',{exact:true})).toBeChecked();expect((await calls(page,'autostart_set')).length).toBe(1);
  350 | });
  351 | 
```